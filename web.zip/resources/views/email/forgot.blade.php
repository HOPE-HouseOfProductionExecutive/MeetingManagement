<h1>Hallo, {{ $user->fullname }}</h1>
<p>
    Password anda sudah kami reset menjadi "rapat123". Silahkan login dan mengganti password anda.
</p>
