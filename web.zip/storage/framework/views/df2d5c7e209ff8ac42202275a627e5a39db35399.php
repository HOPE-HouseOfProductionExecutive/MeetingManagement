<h1>Hallo, <?php echo e($user->fullname); ?></h1>
<p>
    Password anda sudah kami reset menjadi "rapat123". Silahkan login dan mengganti password anda.
</p>
<?php /**PATH C:\Users\myrhe\Documents\PH\New folder\MeetingManagement\resources\views/email/forgot.blade.php ENDPATH**/ ?>